﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Utilities
{
    class Program
    {
        static void Main(string[] args)
        {
            //string strTest = "encryption test";


            //string encrypted = Crypt.Encrypt(original, Crypt.myAESKey , Crypt.myAesIV);
            //string roundtrip = Crypt.Decrypt(encrypted, Crypt.myAESKey, Crypt.myAesIV);

            ////Display the strTest data and the decrypted data.
            //Console.WriteLine("Original:   {0}", strTest);
            //Console.WriteLine("Encrypted:   {0}", encrypted);
            //Console.WriteLine("Round Trip: {0}", roundtrip);
            //Console.ReadLine();
         
        }
    }
}
