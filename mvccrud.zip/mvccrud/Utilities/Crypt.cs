﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Configuration;
using System.Collections.Specialized;

namespace Utilities
{
    public static class Crypt
    {
        public static string AESKey;
        public static string AESIV;
        public static byte[] myAESKey = Encoding.ASCII.GetBytes("??d,?6n??UwI??H?????,?wm??????");
        public static byte[] myAesIV = Encoding.ASCII.GetBytes("?.??#+??$e???+");  


        public static string Encrypt(string textToEncrypt, byte[] aesKey, byte[] aesIV)
        {
             
            if (textToEncrypt == null || textToEncrypt.Length <= 0)
                throw new ArgumentNullException("textToEncrypt");
            if (aesKey == null || aesKey.Length <= 0)
                throw new ArgumentNullException("aesKey");
            if (aesIV == null || aesIV.Length <= 0)
                throw new ArgumentNullException("aesIV");
            byte[] encrypted;

          
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = aesKey;
                aesAlg.IV = aesIV;

                
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

            
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        { 
                            swEncrypt.Write(textToEncrypt);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            } 

            return Encoding.Default.GetString(encrypted);
        }

        public static string Encrypt(string textToEncrypt)
        {

            if (textToEncrypt == null || textToEncrypt.Length <= 0)
                throw new ArgumentNullException("textToEncrypt");
            if (myAESKey == null || myAESKey.Length <= 0)
                throw new ArgumentNullException("aesKey");
            if (myAesIV == null || myAesIV.Length <= 0)
                throw new ArgumentNullException("aesIV");
            byte[] encrypted;


            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = myAESKey;
                aesAlg.IV = myAesIV;


                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);


                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(textToEncrypt);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            return Encoding.Default.GetString(encrypted);
        }

        public static string Decrypt(string decryptText, byte[] aesKey, byte[] aesIV)
        {
            byte[] cipherText = Encoding.Default.GetBytes(decryptText);

           
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (aesKey == null || aesKey.Length <= 0)
                throw new ArgumentNullException("aesKey");
            if (aesIV == null || aesIV.Length <= 0)
                throw new ArgumentNullException("aesIV");

         
            string plaintext = null;

         
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = aesKey;
                aesAlg.IV = aesIV; 
               
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV); 
             
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        { 
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }

            return plaintext;
        }

        public static string Decrypt(string decryptText)
        {
            byte[] cipherText = Encoding.Default.GetBytes(decryptText);


            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (myAESKey == null || myAESKey.Length <= 0)
                throw new ArgumentNullException("aesKey");
            if (myAesIV == null || myAesIV.Length <= 0)
                throw new ArgumentNullException("aesIV");


            string plaintext = null;


            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = myAESKey;
                aesAlg.IV = myAesIV;

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }

            return plaintext;
        }
    }
}
