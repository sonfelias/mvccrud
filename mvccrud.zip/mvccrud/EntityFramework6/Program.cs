﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityFramework6
{
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data"));

            //using (var storeContext = new StoreContext())
            //{
            //    var product = new Product() { ProductName = "Product4", ProductDescription = "ProductDescription4", Price = Convert.ToDecimal(1.05), DateTimeStamp = DateTime.Now, StoreRefNo = 3 };
            //    storeContext.Products.Add(product);
            //    storeContext.SaveChanges();


            //    Console.Write("product added");
            //    Console.ReadLine();

            //    //storeContext.Database.Delete();
            //}
            
        }
    }
}
