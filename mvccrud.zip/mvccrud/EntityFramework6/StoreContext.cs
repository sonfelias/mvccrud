﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity;

namespace EntityFramework6
{
    public class StoreContext : DbContext
    {
        public StoreContext() : base("name=DefaultConnection")
        {
            Database.SetInitializer<StoreContext>(new StoreDBInitializer());
        }

        public DbSet<Store> Stores { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
