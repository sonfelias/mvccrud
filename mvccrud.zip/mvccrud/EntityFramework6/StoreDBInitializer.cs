﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity;
using Utilities;

namespace EntityFramework6
{
    public class StoreDBInitializer : DropCreateDatabaseAlways<StoreContext>
    {
        protected override void Seed(StoreContext context)
        {
            IList<Store> stores = new List<Store>();
            stores.Add(new Store() { StoreName = "Store1", Location = "StoreLocation1" });
            stores.Add(new Store() { StoreName = "Store2", Location = "StoreLocation2" });
            stores.Add(new Store() { StoreName = "Store3", Location = "StoreLocation3" });
            context.Stores.AddRange(stores);

            IList<Product> products = new List<Product>();
            products.Add(new Product() { ProductName = "Product1", ProductDescription = "ProductDescription1", Price = Convert.ToDecimal(1.50), DateTimeStamp = DateTime.Now, StoreRefNo = 1 });
            products.Add(new Product() { ProductName = "Product2", ProductDescription = "ProductDescription2", Price = Convert.ToDecimal(1.25), DateTimeStamp = DateTime.Now, StoreRefNo = 1 });
            products.Add(new Product() { ProductName = "Product3", ProductDescription = "ProductDescription3", Price = Convert.ToDecimal(1.15), DateTimeStamp = DateTime.Now, StoreRefNo = 2 });
            context.Products.AddRange(products);

            IList<User> users = new List<User>();           
            users.Add(new User() { UserName = "asdf", Password = Utilities.Crypt.Encrypt("asdf") });
            context.Users.AddRange(users);

            base.Seed(context);
        }
    }
}
