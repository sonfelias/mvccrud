﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EntityFramework6
{
    public class Product
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ProductNo { get; set; }

        [Required(ErrorMessage = "Product Name is required.")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Product Description is required.")] 
        public string ProductDescription { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [RegularExpression(@"^(((\d{1,3})(,\d{3})*)|(\d+))(.\d+)?$", ErrorMessage = "Invalid Price.")]
        [Range(0.01, Int32.MaxValue, ErrorMessage = "Invalid Price.")]
        public decimal Price { get; set; }   
 
        public DateTime DateTimeStamp { get; set; }

        
        public int StoreRefNo { get; set; }
        public Store Store { get; set; }
    }
}
