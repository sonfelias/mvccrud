﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EntityFramework6
{
    public class Store
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int StoreNo { get; set; }
        public string StoreName { get; set; }
        public string Location { get; set; }

        //[ForeignKey("StoreRefNo")]
        public ICollection<Product> Products { get; set; }
    }
}
