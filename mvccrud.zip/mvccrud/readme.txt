please update the connection string in mvccrud project
login username is asdf password is asdf