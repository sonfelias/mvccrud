﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvccrud.Models
{
    public class StoreProductModel
    {
        public StoreModel Store { get; set; }
        public ProductModel Product { get; set; }
    }
}