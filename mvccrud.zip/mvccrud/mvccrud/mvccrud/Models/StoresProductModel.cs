﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace mvccrud.Models
{
    public class StoresProductModel
    {
        
        public IEnumerable<StoreModel> Stores { get; set; }
        public ProductModel Product { get; set; }
    }
}