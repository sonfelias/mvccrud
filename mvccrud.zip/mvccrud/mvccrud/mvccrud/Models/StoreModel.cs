﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EntityFramework6;

namespace mvccrud.Models
{
    public class StoreModel : Store
    {
        
    }
}