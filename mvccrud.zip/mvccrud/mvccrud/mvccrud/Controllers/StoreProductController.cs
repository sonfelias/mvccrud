﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvccrud.Models;
using EntityFramework6;

namespace mvccrud.Controllers
{
    public class StoreProductController : Controller
    {
        //
        // GET: /StoreProduct/
        StoreContext storeContext = new StoreContext();

        public ActionResult Index(FormCollection form)
        {
            ViewBag.Message = "Store Products...";
            StoreProductViewModel spModel = new StoreProductViewModel();
            spModel.Stores = GetStores();
 
            if (string.IsNullOrEmpty(form["Stores"]))
            {
                spModel.Products = GetProducts();
            }
            else {
                spModel.Products = GetProductsByStoreNo(Convert.ToInt32(form["Stores"].ToString()));
            }
            return View(spModel);
             
        }

        //
        // GET: /StoreProduct/Details/5

        public ActionResult Details(int id)
        {
            ProductModel pm = GetProductsByProductNo(id);
            StoreModel sm = GetStoreByStoreNo(pm.StoreRefNo);
            StoreProductModel spm = new StoreProductModel();
            spm.Store = sm;
            spm.Product = pm;            
            return View(spm);
        }

        //
        // GET: /StoreProduct/Create

        public ActionResult Create()
        {
            ProductModel pm = new ProductModel();
            IEnumerable<StoreModel> stores = GetStores();
            StoresProductModel spm = new StoresProductModel();
            spm.Stores = stores;
            spm.Product = pm;
            return View(spm);
        }

        //
        // POST: /StoreProduct/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                bool isValid = true;
                if (string.IsNullOrEmpty(collection["Product.ProductName"].ToString())){
                    ModelState.AddModelError("", "Product Name is required.");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(collection["Product.ProductDescription"].ToString()))
                {
                    ModelState.AddModelError("", "Product Description is required.");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(collection["Product.Price"].ToString()))
                {
                    ModelState.AddModelError("", "Price is required.");
                    isValid = false;
                }

                if (isValid == false) {
                    return RedirectToAction("Create");
                }

                if (ModelState.IsValid)
                {
                    Product product = new Product();
                    if (product != null)
                    {
                        product.ProductName = collection["Product.ProductName"];
                        product.ProductDescription = collection["Product.ProductDescription"];
                        product.Price = Convert.ToDecimal(collection["Product.Price"]);
                        product.DateTimeStamp = DateTime.Now;
                        product.StoreRefNo = Convert.ToInt32(collection["Stores"]);
                        storeContext.Products.Add(product);
                        storeContext.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return RedirectToAction("Create");
                    }
                }
                return RedirectToAction("Create");
            }
            catch( Exception ex )
            {
                return View();
            }
        }

        //
        // GET: /StoreProduct/Edit/5

        public ActionResult Edit(int id)
        { 
            ProductModel pm = GetProductsByProductNo(id);
            StoreModel sm = GetStoreByStoreNo(pm.StoreRefNo);
            StoreProductModel spm = new StoreProductModel();
            spm.Store = sm;
            spm.Product = pm;
            return View(spm);
        }

        //
        // POST: /StoreProduct/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                bool isValid = true;
                if (string.IsNullOrEmpty(collection["Product.ProductName"].ToString()))
                {
                    ModelState.AddModelError("", "Product Name is required.");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(collection["Product.ProductDescription"].ToString()))
                {
                    ModelState.AddModelError("", "Product Description is required.");
                    isValid = false;
                }
                if (string.IsNullOrEmpty(collection["Product.Price"].ToString()))
                {
                    ModelState.AddModelError("", "Price is required.");
                    isValid = false;
                }

                if (isValid == false)
                {
                    return RedirectToAction("Edit");
                }

                if (ModelState.IsValid)
                {
                    Product product = storeContext.Products.Find(id);
                    if (product != null)
                    {
                        product.ProductName = collection["Product.ProductName"];
                        product.ProductDescription = collection["Product.ProductDescription"];
                        product.Price = Convert.ToDecimal(collection["Product.Price"]);
                        storeContext.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return RedirectToAction("Details");
                    }
                }
                else {
                    return RedirectToAction("Details");
                }
                
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /StoreProduct/Delete/5

        public ActionResult Delete(int id)
        {
            ProductModel pm = GetProductsByProductNo(id);
            StoreModel sm = GetStoreByStoreNo(pm.StoreRefNo);
            StoreProductModel spm = new StoreProductModel();
            spm.Store = sm;
            spm.Product = pm;
            return View(spm);
        }

        //
        // POST: /StoreProduct/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                Product product = storeContext.Products.Find(id);
                if (product != null)
                {
                    storeContext.Products.Remove(product);
                    storeContext.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    return RedirectToAction("Index");
                }

            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult Submit(FormCollection form)
        {
            ViewBag.Message = "Store Products...";
            string storeDDLValue = form["Stores"].ToString();
            StoreProductViewModel spModel = new StoreProductViewModel();
            spModel.Stores = GetStores();
            spModel.Products = GetProductsByStoreNo(Convert.ToInt32(storeDDLValue));
            return View(spModel);

        }

        private IEnumerable<StoreModel> GetStores() {
            var records = storeContext.Stores.OrderBy(a => a.StoreName).AsEnumerable(); 

            var stores = new List<StoreModel>();
             foreach(Store store in records){
                 StoreModel sm = new StoreModel();
                 sm.StoreNo = store.StoreNo;
                 sm.StoreName = store.StoreName;
                 sm.Location = store.Location;
                 stores.Add(sm);
             }

             return stores.AsEnumerable();
        }

        private IEnumerable<ProductModel> GetProducts()
        {
             
            var records = storeContext.Products.OrderBy(a => a.ProductNo).AsEnumerable();

            var products = new List<ProductModel>();
            foreach (Product product in records)
            {
                ProductModel pm = new ProductModel();
                pm.ProductNo = product.ProductNo;
                pm.ProductName = product.ProductName;
                pm.ProductDescription = product.ProductDescription;
                pm.Price = product.Price;
                pm.StoreRefNo = product.StoreRefNo;
                pm.DateTimeStamp = product.DateTimeStamp;
                products.Add(pm);
            }

            return products.AsEnumerable();
        }

        private IEnumerable<ProductModel> GetProductsByStoreNo(int storeNo)
        {
            
            var records = storeContext.Products.Where(p => p.StoreRefNo == storeNo).AsEnumerable();

            var products = new List<ProductModel>();
            foreach (Product product in records)
            {
                ProductModel pm = new ProductModel();
                pm.ProductNo = product.ProductNo;
                pm.ProductName = product.ProductName;
                pm.ProductDescription = product.ProductDescription;
                pm.Price = product.Price;
                pm.StoreRefNo = product.StoreRefNo;
                pm.DateTimeStamp = product.DateTimeStamp;
                products.Add(pm);
            }

            return products.AsEnumerable();
        }

        private ProductModel GetProductsByProductNo(int productNo)
        {
            var records = storeContext.Products.Where(p => p.ProductNo == productNo).AsEnumerable();
            Product record = storeContext.Products.Find(productNo);
            ProductModel pm = new ProductModel();
            if (record != null)
            {
                pm.ProductNo = record.ProductNo;
                pm.ProductName = record.ProductName;
                pm.ProductDescription = record.ProductDescription;
                pm.Price = record.Price;
                pm.StoreRefNo = record.StoreRefNo;
                pm.DateTimeStamp = record.DateTimeStamp;
            }

            return pm; 
 
        }

        private StoreModel GetStoreByStoreNo(int storeNo)
        {

            Store record = storeContext.Stores.Find(storeNo);
            StoreModel sm = new StoreModel();
            if (record != null) {
                sm.StoreNo = record.StoreNo;
                sm.StoreName = record.StoreName;
                sm.Location = record.Location;
            } 

            return sm;
        }
    }
}
