﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityFramework6;
using Utilities;

namespace mvccrud.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        StoreContext storeContext = new StoreContext();

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here 
                string userName = collection["UserName"].ToString();
                EntityFramework6.User user = storeContext.Users.Where(p => p.UserName == userName).FirstOrDefault<EntityFramework6.User>();

                if (user != null)
                { 
                     
                    string passWord = Utilities.Crypt.Encrypt(collection["Password"]);

                    if (user.UserName == userName && user.Password == passWord)
                    {
                        return RedirectToAction("Index", "StoreProduct");
                    }

                    ModelState.AddModelError("", "Incorrect UserName or Password."); 
                    return View("Login");
                }
                else
                {
                    ModelState.AddModelError("", "Incorrect UserName or Password."); 
                    return View("Login");
                }

            }
            catch (Exception ex)
            {
                return View();
            };
             
        }

         
    }
}
